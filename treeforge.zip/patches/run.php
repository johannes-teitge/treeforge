<?php
declare(strict_types=1);

$patchDir = __DIR__;
$root = dirname(__DIR__);

$executedFile = $patchDir . '/executed.json';
$historyFile = $root . '/storage/system/patch-history.json';
$logFile = $root . '/storage/logs/patch-runner.log';

function runnerLog(string $message): void
{
    global $logFile;

    $line = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
    echo $line;

    if (!is_dir(dirname($logFile))) {
        mkdir(dirname($logFile), 0775, true);
    }

    file_put_contents($logFile, $line, FILE_APPEND);
}

function loadJsonFile(string $file): array
{
    if (!file_exists($file)) {
        return [];
    }

    $data = json_decode((string)file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function saveJsonFile(string $file, array $data): void
{
    if (!is_dir(dirname($file))) {
        mkdir(dirname($file), 0775, true);
    }

    file_put_contents(
        $file,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
    );
}

$executed = loadJsonFile($executedFile);
$history = loadJsonFile($historyFile);

$patches = glob($patchDir . '/patch-*.php') ?: [];
sort($patches);

runnerLog('Patch Runner gestartet');

foreach ($patches as $patchFile) {
    $patchName = basename($patchFile);

    if (isset($executed[$patchName])) {
        runnerLog("Übersprungen: {$patchName}");
        continue;
    }

    $messages = [];
    $startedAt = microtime(true);

    $patchLog = function (string $message) use (&$messages): void {
        $messages[] = [
            'time' => date('c'),
            'message' => $message,
        ];

        runnerLog($message);
    };

    runnerLog("Starte: {$patchName}");

    $patch = require $patchFile;

    if (!is_callable($patch)) {
        $durationMs = (int)round((microtime(true) - $startedAt) * 1000);

        $history[$patchName] = [
            'executed_at' => date('c'),
            'status' => 'error',
            'duration_ms' => $durationMs,
            'error' => 'Patch gibt keine callable Funktion zurück',
            'messages' => $messages,
        ];

        saveJsonFile($historyFile, $history);

        runnerLog("FEHLER: {$patchName} gibt keine Funktion zurück");
        exit(1);
    }

    try {
        $patch($root, $patchLog);

        $durationMs = (int)round((microtime(true) - $startedAt) * 1000);

        $executed[$patchName] = [
            'executed_at' => date('c'),
            'status' => 'ok',
        ];

        $history[$patchName] = [
            'executed_at' => date('c'),
            'status' => 'ok',
            'duration_ms' => $durationMs,
            'messages' => $messages,
        ];

        saveJsonFile($executedFile, $executed);
        saveJsonFile($historyFile, $history);

        runnerLog("Fertig: {$patchName} ({$durationMs} ms)");
    } catch (Throwable $e) {
        $durationMs = (int)round((microtime(true) - $startedAt) * 1000);

        $history[$patchName] = [
            'executed_at' => date('c'),
            'status' => 'error',
            'duration_ms' => $durationMs,
            'error' => $e->getMessage(),
            'messages' => $messages,
        ];

        saveJsonFile($historyFile, $history);

        runnerLog("FEHLER in {$patchName}: " . $e->getMessage());
        exit(1);
    }
}

runnerLog('Patch Runner beendet');