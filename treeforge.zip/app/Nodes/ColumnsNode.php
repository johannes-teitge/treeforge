<?php
declare(strict_types=1);

namespace TreeForge\Nodes;

use TreeForge\Core\Node;
use TreeForge\Core\NodeFactory;

class ColumnsNode extends Node
{
    public function count(): int
    {
        return (int)($this->data['settings']['columns'] ?? count($this->data['children'] ?? []));
    }

    public function gap(): string
    {
        return (string)($this->data['settings']['gap'] ?? '1rem');
    }

    public function children(): array
    {
        $nodes = [];

        foreach ($this->data['children'] ?? [] as $nodeData) {
            $nodes[] = NodeFactory::create($nodeData);
        }

        return $nodes;
    }
}